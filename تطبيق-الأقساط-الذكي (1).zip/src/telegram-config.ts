export interface TelegramConfigType {
  BOT_TOKEN: string;
  CHAT_ID: string;
  BACKUP_PREFIX: string;
  DB_NAME: string;
  STORE_NAME: string;
}

export const TelegramConfig: TelegramConfigType = {
  BOT_TOKEN: "8861652138:AAE5TCmuVRF0EJ-sTYQNNNGf037rYZ_KH5s",
  CHAT_ID: "5380768940",
  BACKUP_PREFIX: "AlAqsat_Text_",
  DB_NAME: "AlAqsatOfflineDb",
  STORE_NAME: "customers"
};

// Declare on window object for global availability exactly as requested
declare global {
  interface Window {
    TelegramConfig: TelegramConfigType;
  }
}

if (typeof window !== "undefined") {
  window.TelegramConfig = TelegramConfig;
}
