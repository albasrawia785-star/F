import { TelegramConfig } from "./telegram-config";

// Interface for Customer and sub-objects to keep TypeScript happy
interface Payment {
  date: string;
  amount: number;
}

interface CustomerImages {
  personal?: string;
  resFront?: string;
  resBack?: string;
  idFront?: string;
  idBack?: string;
}

interface GuarantorImages {
  personal?: string;
  idFront?: string;
  idBack?: string;
  resFront?: string;
  resBack?: string;
}

interface Guarantor {
  name: string;
  phone: string;
  address: string;
  nationalId?: string;
  images?: GuarantorImages;
}

interface Customer {
  id: string;
  name: string;
  phone: string;
  nationalId?: string;
  productName: string;
  productSerial: string;
  totalAmount: number;
  upfront: number;
  monthlyAmount: number;
  remainingAmount: number;
  dueDay: number;
  images?: CustomerImages;
  payments: Payment[];
  status: 'active' | 'done';
  dateAdded: string;
  hasGuarantor?: boolean;
  guarantor?: Guarantor;
  governorate?: string;
  nearestLandmark?: string;
}

/**
 * 3️⃣ واجهة إشعار حالة المزامنة اللحظية (UI Toast)
 * دالة لإظهار تنبيه مرئي صغير ومتحرك أسفل الشاشة يناسب الهواتف الذكية.
 */
let activeToast: HTMLDivElement | null = null;

export function showSyncToast(message: string, type: "loading" | "success" | "error"): void {
  if (typeof document === "undefined") return;

  // Remove active toast if exists
  if (activeToast) {
    activeToast.remove();
    activeToast = null;
  }

  const toast = document.createElement("div");
  toast.className = "fixed bottom-6 left-1/2 -translate-x-1/2 z-[9999] px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-3 text-right direction-rtl transition-all duration-300 transform scale-90 opacity-0 select-none max-w-[90%] w-auto min-w-[280px] border backdrop-blur-md";

  let icon = "";
  let bgClass = "";
  let textClass = "";
  let borderClass = "";

  if (type === "loading") {
    icon = `<svg class="animate-spin h-5 w-5 text-amber-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>`;
    bgClass = "bg-[#1E293B]/95";
    textClass = "text-slate-100 font-bold text-xs";
    borderClass = "border-slate-700/50";
  } else if (type === "success") {
    icon = `<span class="text-emerald-400 text-lg">✅</span>`;
    bgClass = "bg-emerald-950/95";
    textClass = "text-emerald-100 font-bold text-xs";
    borderClass = "border-emerald-800/50";
  } else {
    icon = `<span class="text-rose-400 text-lg">⚠️</span>`;
    bgClass = "bg-rose-950/95";
    textClass = "text-rose-100 font-bold text-xs";
    borderClass = "border-rose-800/50";
  }

  toast.className += ` ${bgClass} ${textClass} ${borderClass}`;
  toast.innerHTML = `
    <div class="flex-shrink-0">${icon}</div>
    <div class="flex-grow font-black text-xs leading-relaxed text-right" style="font-family: 'Inter', sans-serif;">${message}</div>
  `;

  document.body.appendChild(toast);
  activeToast = toast;

  // Animate Entrance
  requestAnimationFrame(() => {
    toast.style.opacity = "1";
    toast.style.transform = "translateX(-50%) scale(1)";
  });

  // Auto remove for success/error
  if (type !== "loading") {
    setTimeout(() => {
      if (activeToast === toast) {
        toast.style.opacity = "0";
        toast.style.transform = "translateX(-50%) scale(0.9)";
        setTimeout(() => {
          toast.remove();
          if (activeToast === toast) activeToast = null;
        }, 300);
      }
    }, 4000);
  }
}

/**
 * Opens IndexedDB using current TelegramConfig settings
 */
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(TelegramConfig.DB_NAME);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(TelegramConfig.STORE_NAME)) {
        db.createObjectStore(TelegramConfig.STORE_NAME, { keyPath: "id" });
      }
    };
  });
}

/**
 * Fetches all local customer records from IndexedDB
 */
async function getLocalCustomers(): Promise<Customer[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    try {
      const transaction = db.transaction(TelegramConfig.STORE_NAME, "readonly");
      const store = transaction.objectStore(TelegramConfig.STORE_NAME);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Replaces all local customer records in IndexedDB while preserving images
 */
async function clearAndWriteCustomers(newCustomers: Customer[]): Promise<void> {
  const db = await openDB();
  
  // First, get all current local customers to preserve their images
  const localCustomers = await getLocalCustomers();
  const imageCache = new Map<string, { customerImages?: CustomerImages; guarantorImages?: GuarantorImages }>();
  
  for (const local of localCustomers) {
    imageCache.set(local.id, {
      customerImages: local.images,
      guarantorImages: local.guarantor?.images
    });
  }

  // Merge images back into incoming text data to prevent local document loss
  const mergedCustomers = newCustomers.map(incoming => {
    const cached = imageCache.get(incoming.id);
    if (cached) {
      const updated = { ...incoming };
      if (cached.customerImages) {
        updated.images = cached.customerImages;
      }
      if (cached.guarantorImages && updated.guarantor) {
        updated.guarantor = {
          ...updated.guarantor,
          images: cached.guarantorImages
        };
      }
      return updated;
    }
    return incoming;
  });

  return new Promise((resolve, reject) => {
    const transaction = db.transaction(TelegramConfig.STORE_NAME, "readwrite");
    const store = transaction.objectStore(TelegramConfig.STORE_NAME);
    
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);

    // Clear existing records
    store.clear();

    // Write new merged records
    for (const cust of mergedCustomers) {
      store.put(cust);
    }
  });
}

/**
 * 1️⃣ عملية الفحص والجلب التلقائي عند فتح التطبيق
 * تتحقق في الخلفية فور تشغيل التطبيق وتجري مزامنة صامتة إن وجد ملف أحدث.
 */
export async function checkAndRestoreFromTelegram(): Promise<void> {
  const token = TelegramConfig.BOT_TOKEN;
  const chatId = TelegramConfig.CHAT_ID;
  const prefix = TelegramConfig.BACKUP_PREFIX;

  if (!token || !chatId) {
    console.warn("Telegram Sync is disabled: BOT_TOKEN or CHAT_ID is not configured.");
    return;
  }

  try {
    let latestDocMessage: any = null;

    // A. Check for pinned message (Extremely reliable permanent lookup)
    try {
      const getChatUrl = `https://api.telegram.org/bot${token}/getChat?chat_id=${chatId}`;
      const chatRes = await fetch(getChatUrl);
      const chatData = await chatRes.json();
      
      if (chatData.ok && chatData.result?.pinned_message) {
        const pinned = chatData.result.pinned_message;
        if (pinned.document && pinned.document.file_name.startsWith(prefix)) {
          latestDocMessage = pinned;
          console.log("Found backup file in pinned message:", pinned.document.file_name);
        }
      }
    } catch (e) {
      console.warn("Failed to check pinned message in Telegram:", e);
    }

    // B. Fallback to getUpdates if no pinned message found
    if (!latestDocMessage) {
      try {
        const getUpdatesUrl = `https://api.telegram.org/bot${token}/getUpdates?allowed_updates=["message"]`;
        const updatesRes = await fetch(getUpdatesUrl);
        const updatesData = await updatesRes.json();
        
        if (updatesData.ok && Array.isArray(updatesData.result)) {
          for (let i = updatesData.result.length - 1; i >= 0; i--) {
            const item = updatesData.result[i];
            const message = item.message || item.channel_post;
            if (message && message.document && message.document.file_name.startsWith(prefix)) {
              latestDocMessage = message;
              console.log("Found backup file in getUpdates:", message.document.file_name);
              break;
            }
          }
        }
      } catch (e) {
        console.warn("Failed to fetch getUpdates from Telegram:", e);
      }
    }

    if (!latestDocMessage) {
      console.log("No remote Telegram backups found starting with prefix:", prefix);
      return;
    }

    // Extract dates
    const remoteTimestamp = latestDocMessage.date * 1000; // Telegram uses Unix seconds
    const localTimestampStr = localStorage.getItem("last_db_update_timestamp");
    const localTimestamp = localTimestampStr ? Number(localTimestampStr) : 0;

    console.log(`Telegram Sync - Remote Backup Date: ${new Date(remoteTimestamp).toLocaleString()}`);
    console.log(`Telegram Sync - Local DB Update Date: ${new Date(localTimestamp).toLocaleString()}`);

    if (remoteTimestamp > localTimestamp + 2000) { // Offset 2 seconds buffer
      showSyncToast("🔄 جاري تحميل وتحديث قاعدة البيانات من السحابة صامتاً...", "loading");

      // 1. Get file path
      const fileId = latestDocMessage.document.file_id;
      const getFileUrl = `https://api.telegram.org/bot${token}/getFile?file_id=${fileId}`;
      const fileRes = await fetch(getFileUrl);
      const fileData = await fileRes.json();

      if (!fileData.ok || !fileData.result?.file_path) {
        throw new Error("Failed to get file path from Telegram Bot API");
      }

      const filePath = fileData.result.file_path;
      const downloadUrl = `https://api.telegram.org/file/bot${token}/${filePath}`;

      // 2. Fetch the backup JSON
      const backupRes = await fetch(downloadUrl);
      const backupText = await backupRes.text();
      const backupJson = JSON.parse(backupText);

      let importedCustomers: Customer[] = [];
      if (Array.isArray(backupJson)) {
        importedCustomers = backupJson;
      } else if (backupJson && Array.isArray(backupJson.customers)) {
        importedCustomers = backupJson.customers;
      } else {
        throw new Error("Invalid backup file format");
      }

      // 3. Write into IndexedDB while merging local images
      await clearAndWriteCustomers(importedCustomers);

      // 4. Update localStorage timestamp to match remote backup date
      localStorage.setItem("last_db_update_timestamp", remoteTimestamp.toString());

      showSyncToast("✅ تم تحديث ومزامنة البيانات النصية سحابياً بنجاح!", "success");

      // Reload UI to show new content
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } else {
      console.log("Local database is up to date with Telegram cloud.");
    }
  } catch (error) {
    console.error("Error running auto check and restore from Telegram:", error);
    showSyncToast("❌ فشل تحديث المزامنة السحابية الصامتة.", "error");
  }
}

/**
 * Helper to strip images from a customer object for space optimization
 */
function sanitizeCustomerForBackup(customer: Customer): Customer {
  const clone = JSON.parse(JSON.stringify(customer)) as Customer;
  
  // Wipe out base64 images
  if (clone.images) {
    delete clone.images.personal;
    delete clone.images.resFront;
    delete clone.images.resBack;
    delete clone.images.idFront;
    delete clone.images.idBack;
  }
  
  if (clone.guarantor && clone.guarantor.images) {
    delete clone.guarantor.images.personal;
    delete clone.guarantor.images.resFront;
    delete clone.guarantor.images.resBack;
    delete clone.guarantor.images.idFront;
    delete clone.guarantor.images.idBack;
  }

  return clone;
}

/**
 * 2️⃣ عملية الرفع التلقائي الصامت (عند أي تعديل)
 * تأخذ نسخة من البيانات، تزيل منها الصور، وترسلها صامتة إلى تليجرام.
 */
export async function uploadBackupToTelegram(): Promise<void> {
  const token = TelegramConfig.BOT_TOKEN;
  const chatId = TelegramConfig.CHAT_ID;
  const prefix = TelegramConfig.BACKUP_PREFIX;

  if (!token || !chatId) {
    console.warn("Telegram Sync is disabled: BOT_TOKEN or CHAT_ID is not configured.");
    return;
  }

  showSyncToast("🔄 جاري حفظ ومزامنة التعديلات سحابياً...", "loading");

  try {
    // 1. Get current local customers
    const customers = await getLocalCustomers();

    // 2. Filter out heavy base64 images to make the backup light and fast
    const textOnlyCustomers = customers.map(sanitizeCustomerForBackup);

    // 3. Create blob file
    const fileContent = JSON.stringify(textOnlyCustomers, null, 2);
    const blob = new Blob([fileContent], { type: "application/json" });
    const timestamp = Date.now();
    const fileName = `${prefix}${timestamp}.json`;

    // 4. Prepare multipart form data
    const formData = new FormData();
    formData.append("chat_id", chatId);
    formData.append("document", blob, fileName);
    formData.append("caption", `📥 نسخة احتياطية تلقائية (نصوص فقط)\n⏰ التوقيت: ${new Date().toLocaleString()}`);
    formData.append("disable_notification", "true"); // Silent upload

    // 5. Upload via Telegram Bot API
    const sendDocUrl = `https://api.telegram.org/bot${token}/sendDocument`;
    const response = await fetch(sendDocUrl, {
      method: "POST",
      body: formData
    });

    const result = await response.json();

    if (!result.ok) {
      throw new Error(result.description || "Failed to upload document to Telegram");
    }

    const messageId = result.result.message_id;
    const telegramDate = result.result.date * 1000; // Milliseconds

    // 6. Pin the message so getChat can reliably find it permanently
    try {
      const pinUrl = `https://api.telegram.org/bot${token}/pinChatMessage?chat_id=${chatId}&message_id=${messageId}&disable_notification=true`;
      await fetch(pinUrl);
    } catch (e) {
      console.warn("Could not pin the backup message, falling back to getUpdates next time:", e);
    }

    // 7. Save the timestamp locally to prevent self-sync loop
    localStorage.setItem("last_db_update_timestamp", telegramDate.toString());

    showSyncToast("✅ تمت المزامنة السحابية الصامتة للملف بنجاح!", "success");
  } catch (error) {
    console.error("Error uploading backup to Telegram:", error);
    showSyncToast("❌ فشلت المزامنة السحابية الصامتة.", "error");
  }
}
